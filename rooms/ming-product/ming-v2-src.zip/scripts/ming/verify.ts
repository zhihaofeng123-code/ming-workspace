import { computePillars, dayPillarForCivilDate, lichunJD, jdToDate, zonedWallClockToMs } from "../../lib/ming/bazi";
import { buildSignal, COPY_COUNTS } from "../../lib/ming/signal";
// @ts-expect-error untyped test-only dependency
import lunar from "lunar-javascript";
const { Solar } = lunar as { Solar: { fromYmdHms: (y: number, m: number, d: number, h: number, mi: number, s: number) => { getLunar: () => { getEightChar: () => { setSect: (n: number) => void; getYear: () => string; getMonth: () => string; getDay: () => string; getTime: () => string } } } } };

let fail = 0;
const check = (name: string, got: string, want: string) => {
  const ok = got === want;
  if (!ok) fail++;
  console.log(`${ok ? "PASS" : "FAIL"}  ${name.padEnd(46)} ${got}${ok ? "" : `   (expected ${want})`}`);
};

console.log("--- solar terms vs Hong Kong Observatory published times");
const terms: [string, number, string][] = [
  ["Lichun 2024", 2024, "2024-02-04T08:27"],
  ["Lichun 2025", 2025, "2025-02-03T14:10"],
  ["Lichun 2026", 2026, "2026-02-03T20:02"],
];
for (const [name, y, want] of terms) {
  check(name, jdToDate(lichunJD(y)).toISOString().slice(0, 16), want);
}

console.log("\n--- day pillars vs published sexagenary anchors");
check("1970-01-01", dayPillarForCivilDate(1970, 1, 1).py, "Xin Si");
check("2000-01-01", dayPillarForCivilDate(2000, 1, 1).py, "Wu Wu");
check("2019-01-27 (jiazi anchor)", dayPillarForCivilDate(2019, 1, 27).py, "Jia Zi");
check("2024-06-15", dayPillarForCivilDate(2024, 6, 15).py, "Geng Xu");

console.log("\n--- full chart vs pyswisseph-derived fixture");
const f = computePillars(Date.UTC(2024, 5, 15, 12, 0), "UTC", 0, false);
check("2024-06-15 12:00 UTC", [f.year.py, f.month.py, f.day.py, f.hour.py].join(" | "), "Jia Chen | Geng Wu | Geng Xu | Ren Wu");

console.log("\n--- 4000 random charts vs lunar-javascript (independent implementation)");
const buckets: Record<string, number> = { year: 0, month: 0, day: 0, hour: 0 };
let lateZi = 0;
const rnd = (a: number, b: number) => a + Math.floor(Math.random() * (b - a + 1));
for (let i = 0; i < 4000; i++) {
  const y = rnd(1940, 2035), mo = rnd(1, 12), d = rnd(1, 28), h = rnd(0, 23), mi = rnd(0, 59);
  if (h === 23) { lateZi++; continue; }
  const mine = computePillars(Date.UTC(y, mo - 1, d, h - 8, mi), "Etc/GMT-8", 0, false);
  const ec = Solar.fromYmdHms(y, mo, d, h, mi, 0).getLunar().getEightChar();
  ec.setSect(2);
  const t = [ec.getYear(), ec.getMonth(), ec.getDay(), ec.getTime()];
  const o = [mine.year.cn, mine.month.cn, mine.day.cn, mine.hour.cn];
  (["year", "month", "day", "hour"] as const).forEach((k, idx) => { if (o[idx] !== t[idx]) buckets[k]++; });
}
for (const k of ["year", "month", "day", "hour"]) check(`${k} pillar mismatches`, String(buckets[k]), "0");
console.log(`      (${lateZi} late-Zi charts skipped: documented convention split)`);

console.log("\n--- regression: repeat behaviour over time (Dev review, item 2)");
const people: [string, number, number, number, number, number, string, number][] = [
  ["A San Francisco 1994", 1994, 3, 17, 7, 42, "America/Los_Angeles", -122.4194],
  ["B London 1988", 1988, 11, 2, 21, 10, "Europe/London", -0.1276],
  ["C New York 2001", 2001, 6, 24, 14, 5, "America/New_York", -74.006],
  ["D Taipei 1996", 1996, 1, 9, 4, 30, "Asia/Taipei", 121.5654],
];
const charts = people.map(([label, y, mo, d, h, mi, tz, lon]) => ({
  label,
  tz,
  natal: computePillars(zonedWallClockToMs(y, mo, d, h, mi, tz), tz, lon, true),
  lon,
}));
// One year of consecutive days per chart, read the way the API reads them.
const series = charts.map((c) => {
  const out: { date: string; s: ReturnType<typeof buildSignal> }[] = [];
  for (let k = 0; k < 365; k++) {
    const t = new Date(Date.UTC(2026, 8, 2 + k));
    const [yy, mm, dd] = [t.getUTCFullYear(), t.getUTCMonth() + 1, t.getUTCDate()];
    const day = computePillars(zonedWallClockToMs(yy, mm, dd, 12, 0, c.tz), c.tz, c.lon, false);
    out.push({ date: `${yy}-${String(mm).padStart(2, "0")}-${String(dd).padStart(2, "0")}`, s: buildSignal(c.natal, day) });
  }
  return { ...c, out };
});

// Dev found every chart got its 09-05 observation back on 09-15. First repeat must now be >= 30.
let worstGap = Infinity;
for (const c of series) {
  const firstSeen = new Map<string, number>();
  let gap = Infinity;
  c.out.forEach((row, i) => {
    const prev = firstSeen.get(row.s.observation);
    if (prev !== undefined) gap = Math.min(gap, i - prev);
    else firstSeen.set(row.s.observation, i);
  });
  worstGap = Math.min(worstGap, gap);
  const distinct = new Set(c.out.map((r) => r.s.observation)).size;
  console.log(`      ${c.label.padEnd(22)} first observation repeat after ${gap} days, ${distinct} distinct observations/year`);
}
check("shortest observation repeat >= 30 days", String(worstGap >= 30), "true");

const fullYear = new Set(series[0].out.map((r) => [r.s.observation, r.s.theme, r.s.action, r.s.notice].join("|")));
console.log(`      full four-line readings in a year for one chart: ${fullYear.size} distinct of 365`);

console.log("\n--- regression: reflection must depend on the chart (Dev review, item 1)");
// Dev: on 2026-09-04 births A and B closed with the identical question.
const sept4 = series.map((c) => {
  const row = c.out.find((r) => r.date === "2026-09-04");
  return { label: c.label, notice: row?.s.notice ?? "" };
});
sept4.forEach((r) => console.log(`      ${r.label.padEnd(22)} ${r.notice}`));
check("A and B differ on 2026-09-04", String(sept4[0].notice !== sept4[1].notice), "true");
let sharedDays = 0;
for (let i = 0; i < 365; i++) {
  if (series[0].out[i].s.notice === series[1].out[i].s.notice) sharedDays++;
}
console.log(`      A and B share a closing question on ${sharedDays} of 365 days (was 45% of sampled days)`);

console.log("\n--- regression: every authored key must be reachable (Dev review, item 7)");
const obsKeys = new Set<string>();
const obsStrings = new Set<string>();
const noticeKeys = new Set<string>();
const rnd2 = (a: number, b: number) => a + Math.floor(Math.random() * (b - a + 1));
for (let i = 0; i < 3000; i++) {
  const natal = computePillars(Date.UTC(rnd2(1960, 2010), rnd2(0, 11), rnd2(1, 28), rnd2(0, 23), rnd2(0, 59)), "UTC", 0, false);
  for (let k = 0; k < 12; k++) {
    const day = computePillars(Date.UTC(2026, 0, 1 + rnd2(0, 360), 12), "UTC", 0, false);
    const sig = buildSignal(natal, day);
    obsKeys.add(sig.keys.observation);
    obsStrings.add(sig.observation);
    noticeKeys.add(sig.keys.notice);
  }
}
check("observation keys reached", String(obsKeys.size), String(COPY_COUNTS.observationKeys));
check("observation strings reached", String(obsStrings.size), String(COPY_COUNTS.observationStrings));
check("notice keys reached", String(noticeKeys.size), String(COPY_COUNTS.noticeStrings));

console.log("\n--- authored string inventory");
console.log(`      observations ${COPY_COUNTS.observationStrings} (${COPY_COUNTS.observationKeys} keys x 3 variants)`);
console.log(`      themes ${COPY_COUNTS.themeStrings}, actions ${COPY_COUNTS.actionStrings}, reflections ${COPY_COUNTS.noticeStrings}`);
console.log(`      total ${COPY_COUNTS.totalStrings} authored strings, all reachable`);

console.log("\n--- regression: same day, different people (Dev review, item 1)");
const day2 = series.map((c) => c.out.find((r) => r.date === "2026-09-02")!.s);
const distinctObs = new Set(day2.map((s) => s.observation)).size;
check("4 charts give 4 distinct observations on 2026-09-02", String(distinctObs), "4");

console.log(fail === 0 ? "\nALL CHECKS PASSED" : `\n${fail} CHECK(S) FAILED`);
process.exit(fail === 0 ? 0 : 1);
