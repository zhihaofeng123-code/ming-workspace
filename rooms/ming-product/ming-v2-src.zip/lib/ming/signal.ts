/**
 * MING daily signal.
 *
 * The four lines are SELECTED by deterministic chart arithmetic and WRITTEN by hand.
 * No language is generated at runtime: every sentence below is authored copy, chosen
 * by an index derived from the natal chart and the target day's pillars.
 *
 *   observation <- Ten God of the target day's stem against the natal day master,
 *                  crossed with how loaded that element is relative to the rest of the
 *                  chart, then rotated between three authored variants
 *   theme       <- direction of the target month's branch element against the day master,
 *                  crossed with the day master's strength band. Presented as a dated
 *                  season, because it holds until the next solar term rather than a day
 *   action      <- Ten God of the primary hidden stem of the target day's branch
 *   notice      <- strongest branch relation (clash / harmony / repeat) between the
 *                  target day's branch and the natal branches; when there is none, the
 *                  day branch's element read against the natal chart
 *
 * Repeat behaviour, which is a product property and not an accident: for a fixed chart
 * every key is a function of the day pillar, so without the variant rotation the whole
 * reading would loop every 60 days and the observation every 10. The rotation is keyed
 * on the sexagenary cycle index plus the natal cycle index, which moves the personal
 * observation repeat to 30 days and de-synchronises two different users.
 *
 * Framing rule for every line: conditions and choices, never prediction. In particular
 * no line asserts that an event will occur or that a third party will act.
 */
import {
  STEMS,
  TEN_GOD_META,
  tenGod,
  phaseDirection,
  elementLoad,
  loadStateFor,
  dayMasterStrength,
  branchRelation,
  type Chart,
  type TenGod,
  type ElementName,
  type PhaseDirection,
  type StrengthBand,
  type LoadState,
  type BranchRelation,
  type ElementShare,
  type Strength,
  type Stem,
  type Branch,
} from "./bazi";

/** Three authored variants per key, rotated so a fixed chart does not loop every 10 days. */
const OBSERVATION: Record<`${TenGod}.${LoadState}`, [string, string, string]> = {
  "friend.scarce": [
    "Standing on your own is not your default, and today asks for it anyway. Independence can feel like exposure before it feels like strength.",
    "You are better supplied by other people than by your own footing, which makes self-reliance costly today rather than natural. Costly is not the same as wrong.",
    "There is little in your chart that props you up from the inside, so holding a position alone takes visible effort today. Effort that shows is still effort that counts.",
  ],
  "friend.present": [
    "You are more sure of your own position today than you may be letting on. The open question is whether you say it plainly or wait to be agreed with first.",
    "Your own footing is steady enough today to take some weight. Test it on something that matters rather than something safe.",
    "You can tell the difference today between what you think and what you have been told to think. Say which is which, at least to yourself.",
  ],
  "friend.saturated": [
    "You already know what you think, and today hands you more of the same conviction. Certainty this smooth is worth testing against one person who does not share it.",
    "Self-reliance is the thing your chart has most of, and today adds to the pile. The risk here is not weakness, it is never asking.",
    "You have more than enough of your own position today. Whether anyone else has been let into the decision is a separate question.",
  ],
  "rival.scarce": [
    "You are not especially practiced at wanting something that someone else also wants. Wanting it out loud is not the same as taking it from anyone.",
    "Competition is unfamiliar ground for this chart and today stands on it. Unfamiliar is what makes it feel personal when it usually is not.",
    "Sharing a goal is not a problem you have had to solve often. The awkwardness in that today is inexperience, not conflict.",
  ],
  "rival.present": [
    "There is a pull today between holding your share and handing it over. Generosity you resent afterwards was not generosity.",
    "Your position and someone else's overlap today. Overlap is not a threat until one of you pretends it is not there.",
    "You can afford to give something away today, which is exactly why it is worth checking whether you want to.",
  ],
  "rival.saturated": [
    "You may catch yourself measuring — output, pace, who got there first. The comparison is real, and it is still not information about your work.",
    "Your chart is crowded with people who want what you want, and today adds one more. Crowded is context, not a verdict.",
    "There is more competition in your reading of the day than there is in the day. Notice which one you are answering.",
  ],
  "craft.scarce": [
    "Making things is not where this chart is rich, and today asks for output anyway. Small and finished beats ambitious and open.",
    "You have less easy expression available than most charts do, so what you produce today carries more weight per unit. Spend it deliberately.",
    "Appetite for making something is unusual for you. Follow it before you interrogate it.",
  ],
  "craft.present": [
    "Output comes more easily today than it usually does. Easy is not the same as unimportant: finish something small rather than opening something large.",
    "There is a workable amount of making in you today. Workable is the useful amount — it does not need to be inspired.",
    "You can enjoy the work today without that meaning it is unserious. Let the enjoyment carry it as far as done.",
  ],
  "craft.saturated": [
    "There is more you could produce today than you can actually finish. Enjoying the work is not the same as moving it.",
    "Your chart makes things easily and today makes it easier. Abundance of output is how half-finished things accumulate.",
    "You will not run short of ideas today. Running short of endings is the likelier problem.",
  ],
  "voice.scarce": [
    "Something you normally leave unsaid sits closer to the surface today. Sharpness that surprises you is worth examining before it is worth using.",
    "Blunt expression is not a well-worn channel here, so when it opens it comes out at the wrong volume. Volume is adjustable; the point underneath usually is not wrong.",
    "You are not practiced at saying the uncomfortable version. That is a reason to write it down first, not a reason to swallow it.",
  ],
  "voice.present": [
    "You can see clearly what is wrong with something today. Being accurate and choosing the moment are two separate decisions.",
    "Your read on the problem is sharp enough to be useful today. Sharp enough to be useful is also sharp enough to cut.",
    "There is a critique in you today that is probably correct. Correct is the easy part.",
  ],
  "voice.saturated": [
    "Your read on the flaw is probably right and probably early. The cost of being right early is that nobody stays for the second half.",
    "This chart runs on unfiltered expression and today turns it up. Turning it up rarely makes it land better.",
    "You have more critique available today than the situation can absorb. Pick the one that changes something.",
  ],
  "opening.scarce": [
    "The openings around you today do not match how you normally get things. Unfamiliar is not the same as unsuitable.",
    "Opportunity is thin in this chart, which makes today's version easy to under-rate. Look at it twice before filing it as noise.",
    "You have little practice taking things that arrive rather than things you built. Arriving is still a legitimate way for something to reach you.",
  ],
  "opening.present": [
    "There is movement available today if you go toward it. Not every open door is worth walking through, and not choosing is also a choice.",
    "Something is reachable today at a reasonable price. Reasonable is worth more than exciting this week.",
    "You have room to take one thing on today. One is the number worth defending.",
  ],
  "opening.saturated": [
    "There is more on offer today than you can hold. Reaching for all of it is the reliable way to end up with none of it.",
    "Your chart attracts options and today adds to them. Options are only an asset once one of them is closed.",
    "Nothing is scarce for you today except attention. Spend that one like it is the scarce thing.",
  ],
  "holding.scarce": [
    "Steady, unglamorous value is thin in this chart, so today's upkeep feels like a detour. Ten minutes now removes a much larger cost later.",
    "You are not naturally drawn to maintaining what already works. Today it is the highest-return thing available.",
    "Keeping something is less familiar to you than starting something. Familiar is not the same as correct today.",
  ],
  "holding.present": [
    "The steady version of what you are building is available today. It is less interesting than the ambitious version and considerably more likely to survive.",
    "Effort converts into something durable today at a fair rate. Fair rates are worth taking.",
    "There is something worth keeping in good condition today. Condition, not expansion.",
  ],
  "holding.saturated": [
    "You may be holding more than needs holding. Worth asking which of it you maintain out of value and which out of habit.",
    "This chart accumulates and today adds to the pile. Addition is easy; the audit is the work.",
    "You are well stocked and today invites more stock. Ask what you would keep if you had to choose half.",
  ],
  "pressure.scarce": [
    "Pressure today is not following a rule you recognise. Name it before you answer it.",
    "Your chart is not built around being pushed, so pressure registers louder than its actual size. Measure it before you react to it.",
    "Demand without a rulebook is unfamiliar here. Unfamiliar is what makes it feel like an attack when it is usually just a demand.",
  ],
  "pressure.present": [
    "There is real demand on you today. You can meet it, redirect it, or delay it, and picking one beats defaulting into the first.",
    "Something is asking more of you today than yesterday. More is not the same as too much.",
    "You have the capacity to absorb today's pressure. Whether absorbing is the right move is the actual question.",
  ],
  "pressure.saturated": [
    "Urgency is loud today and you are practiced at absorbing it. Absorbing is also what teaches the next demand to arrive sooner.",
    "Your chart already carries a lot of push and today adds more. At some point capacity becomes an invitation.",
    "You can take it. That has never been the question.",
  ],
  "structure.scarce": [
    "A rule or an expectation is more visible today than you are used to. Structure you did not ask for can still be worth reading before you push back on it.",
    "Your chart is light on formal structure, so today's version of it feels like an imposition. Read it once as information before you read it as a constraint.",
    "Obligation is not a familiar shape here. That makes it easy to over-comply or dismiss it outright, and neither one is a decision.",
  ],
  "structure.present": [
    "What is expected of you is unusually clear today. Clarity about what is expected is also clarity about what is not.",
    "There is a shape to the day that you did not design. Working inside it is cheaper than arguing with it right now.",
    "Someone's expectation of you is legible today. Legible ones are the ones you can actually negotiate.",
  ],
  "structure.saturated": [
    "You are carrying a lot of should today. Some of it is genuine obligation and some of it is inherited, and they do not deserve equal weight.",
    "This chart runs on structure and today adds another layer. Layers accumulate quietly until one of them has to go.",
    "Responsibility is abundant for you today. Abundance of it is how people stop noticing which parts they chose.",
  ],
  "refuge.scarce": [
    "Support is available today in a shape you would not have picked. Help that does not look like help is easy to turn down by reflex.",
    "Backing on unusual terms is rare in this chart, so today's version arrives without an obvious label. Look at what it does, not what it looks like.",
    "You are not practiced at being helped on someone else's terms. Practice is the only thing that changes that.",
  ],
  "refuge.present": [
    "There is room to step back and think today. Thinking turns into avoidance at a point you can usually feel arriving.",
    "You can go quiet today without that being a retreat. The line is whether you come back with something.",
    "There is support here that does not require you to explain yourself. Use it before you have to.",
  ],
  "refuge.saturated": [
    "You have no shortage of reasons to stay inside your own head today. Interior work has sharply diminishing returns after the second lap.",
    "This chart is well supplied with places to withdraw to, and today opens another. Withdrawal is a tool, not an address.",
    "Reflection is cheap for you today. Cheap things get overused.",
  ],
  "support.scarce": [
    "You may need backing today more than you want to admit. Asking early costs much less than asking once it is urgent.",
    "Ordinary reliable support is thin in this chart, which is probably why you learned to do without it. Learned is not the same as required.",
    "Being carried is unfamiliar. Today is a low-stakes place to find out whether it works.",
  ],
  "support.present": [
    "There is dependable support around you today. Using it does not draw down anyone's account.",
    "Someone is willing to back you today at no particular cost to themselves. That is the cheapest help there is.",
    "You are better resourced today than you are behaving as though you are.",
  ],
  "support.saturated": [
    "Comfort is easy to reach today. The comfort you do not actually need is the expensive kind.",
    "This chart is well supported and today adds more. Support that arrives unrequested is the hardest kind to notice you are leaning on.",
    "You are held today. Held is a good place to make a hard decision from and a bad place to avoid one.",
  ],
};

/** Holds until the next solar term, and is labelled and dated on screen as a season. */
const THEME: Record<`${PhaseDirection}.${StrengthBand}`, string> = {
  "peer.weak": "The stretch you are in is on your side even when you do not feel resourced. Leaning on what is already around you counts as strength.",
  "peer.balanced": "You and this stretch want broadly the same things. That agreement is exactly what makes overcommitting easy.",
  "peer.strong": "This period amplifies what you already are. More of yourself is not automatically the answer.",
  "resource.weak": "This period feeds you. Taking the support is the work right now, not a break from it.",
  "resource.balanced": "More is coming in than going out at the moment. Good conditions for learning something you cannot use yet.",
  "resource.strong": "You are well supplied and the conditions keep supplying. At some point receiving becomes a way of not deciding.",
  "output.weak": "This period pulls output out of you and there is less to give than usual. Choosing what not to make is the real decision.",
  "output.balanced": "The conditions want something made. Pick one and let the rest stay unmade.",
  "output.strong": "You have the capacity and the period wants it spent. Spending it on the wrong thing is the risk, not running out.",
  "wealth.weak": "There is something workable here and less energy to work it with than you would like. Smaller scope, same direction.",
  "wealth.balanced": "Conditions are workable. Effort converts into result at roughly a fair rate right now.",
  "wealth.strong": "You can take on more than this period strictly requires. Whether you should is a separate question.",
  "authority.weak": "The period presses and you are not at full strength. Reducing what you owe beats trying to meet all of it.",
  "authority.balanced": "There is genuine demand right now and you can meet a decent share of it. Deciding the share is your job, not the demand's.",
  "authority.strong": "You can carry what this period is asking. Being able to carry it is how people end up carrying what was never theirs.",
};

const ACTION: Record<TenGod, string> = {
  friend: "State your actual position once, without softening it into a question.",
  rival: "Name one thing you want that someone else also wants. Only name it.",
  craft: "Finish one small thing you already started. Do not open a new one.",
  voice: "Write the criticism down in full and do not send it today.",
  opening: "Say yes to the smallest of the options in front of you and decline the largest.",
  holding: "Do the ten-minute upkeep you keep moving to tomorrow.",
  pressure: "Answer one demand with a specific time rather than a specific outcome.",
  structure: "Take one obligation and check whether anyone still actually expects it.",
  refuge: "Take twenty minutes with no input at all — no feed, no music, no talking.",
  support: "Ask one person for something small and specific.",
};

/** Reflection when today's branch clashes with, harmonises with, or repeats a natal branch. */
const NOTICE_RELATION: Record<string, string> = {
  "clash.day": "What are you defending that nobody has actually attacked?",
  "clash.month": "Whose expectations are you working against today, and did they ever state them out loud?",
  "clash.hour": "What are you hurrying toward that would survive being a week later?",
  "clash.year": "Which old rule of yours is this friction really about?",
  "harmony.day": "What gets easier the moment you stop treating this as a problem to solve?",
  "harmony.month": "Who is easy to work with right now, and have you ever told them so?",
  "harmony.hour": "What would you do next if this went well — and are you ready for that?",
  "harmony.year": "What are you agreeing to because it is comfortable rather than because it is right?",
  "same.day": "Where are you repeating yourself and calling it consistency?",
  "same.month": "What has shown up more than once this month that you keep filing as coincidence?",
  "same.hour": "What do you do at the same time every day without ever deciding to?",
  "same.year": "What have you believed about yourself for so long that you stopped checking?",
};

/**
 * Reflection when today's branch forms no relation with the chart — about 45% of days.
 * Keyed on the day branch's element read *against this chart*: its direction from the day
 * master and how loaded it is here. Two different charts therefore get different closing
 * questions on the same day, which the previous element-only fallback did not do.
 */
const NOTICE_ELEMENT: Record<`${PhaseDirection}.${LoadState}`, string> = {
  "peer.scarce": "What do you rely on yourself for that you have never actually been good at alone?",
  "peer.present": "Where are you the only one holding a thing up, and does it need to be you specifically?",
  "peer.saturated": "What would you still believe about yourself if nobody agreed with you?",
  "output.scarce": "What have you not made yet because you decided you are not the kind of person who makes things?",
  "output.present": "What are you producing that nobody asked for, and is that the good kind or the avoidant kind?",
  "output.saturated": "Which of the things you are making would you actually miss if you stopped?",
  "wealth.scarce": "What do you want that you have quietly decided is not available to you?",
  "wealth.present": "What are you working on whose value you could not explain out loud?",
  "wealth.saturated": "What are you accumulating, and what were you going to do with it?",
  "authority.scarce": "Whose approval are you working for who has never actually asked you for anything?",
  "authority.present": "What are you complying with that you have never once questioned?",
  "authority.saturated": "How much of what you carry was assigned to you, and how much did you volunteer for?",
  "resource.scarce": "Who would help you if you asked, and what stops you asking?",
  "resource.present": "What are you learning right now, and is it for use or for reassurance?",
  "resource.saturated": "What are you being given that you have stopped noticing?",
};

const PILLAR_ORDER = ["day", "month", "hour", "year"] as const;
type PillarKey = (typeof PILLAR_ORDER)[number];
const RELATION_RANK: Record<BranchRelation, number> = { clash: 3, harmony: 2, same: 1, none: 0 };
const mod = (n: number, m: number) => ((n % m) + m) % m;

export type Signal = {
  observation: string;
  theme: string;
  action: string;
  notice: string;
  seasonEndsISO: string | null;
  keys: { observation: string; theme: string; action: string; notice: string; variant: number };
  reasoning: {
    dayMaster: Stem;
    dayStemGod: {
      key: TenGod;
      cn: string;
      classic: string;
      plain: string;
      element: ElementName;
      natalShare: number;
      state: LoadState;
    };
    season: { branch: Branch; direction: PhaseDirection };
    strength: Strength;
    branchGod: { key: TenGod; cn: string; classic: string; plain: string; stem: Stem };
    relation: { relation: BranchRelation; pillar: PillarKey | null };
    noticeElement: { element: ElementName; direction: PhaseDirection; state: LoadState } | null;
    elementShare: ElementShare;
  };
};

/**
 * @param natal chart for the birth moment
 * @param today chart for the target day
 */
export function buildSignal(natal: Chart, today: Chart): Signal {
  const dm = natal.dayMasterIdx;
  const { share } = elementLoad(natal);
  const strength = dayMasterStrength(natal);

  // Rotate authored variants on the sexagenary cycle, offset by the natal cycle index
  // so two people on the same day are not reading the same variant slot.
  const variant = mod(today.meta.dayCycleIndex + natal.meta.dayCycleIndex, 3);

  // 1. observation — what today's stem is doing to this particular chart
  const dayStemGod = tenGod(dm, today.day.stemIdx);
  const dayStemElement = STEMS[today.day.stemIdx].element;
  const state = loadStateFor(dayStemElement, share);
  const observation = OBSERVATION[`${dayStemGod}.${state}`][variant];

  // 2. theme — the season the chart is in, from the month branch against the day master
  const seasonDir = phaseDirection(STEMS[dm].element, today.month.branch.element);
  const theme = THEME[`${seasonDir}.${strength.band}`];

  // 3. action — from the primary hidden stem of today's branch
  const branchPrimary = today.day.branch.hidden[0];
  const branchGod = tenGod(dm, branchPrimary);
  const action = ACTION[branchGod];

  // 4. notice — strongest branch relation with the natal chart, else the day branch's
  //    element read against the natal chart
  let best: { relation: BranchRelation; pillar: PillarKey | null; rank: number } = {
    relation: "none",
    pillar: null,
    rank: 0,
  };
  for (const key of PILLAR_ORDER) {
    const rel = branchRelation(today.day.branchIdx, natal[key].branchIdx);
    const rank = RELATION_RANK[rel];
    if (rank > best.rank) best = { relation: rel, pillar: key, rank };
  }

  let notice: string;
  let noticeKey: string;
  let noticeElement: Signal["reasoning"]["noticeElement"] = null;
  if (best.rank > 0 && best.pillar) {
    noticeKey = `${best.relation}.${best.pillar}`;
    notice = NOTICE_RELATION[noticeKey];
  } else {
    const el = today.day.branch.element;
    const dir = phaseDirection(STEMS[dm].element, el);
    const elState = loadStateFor(el, share);
    noticeKey = `element.${dir}.${elState}`;
    notice = NOTICE_ELEMENT[`${dir}.${elState}`];
    noticeElement = { element: el, direction: dir, state: elState };
  }

  return {
    observation,
    theme,
    action,
    notice,
    seasonEndsISO: today.meta.seasonEndsISO,
    keys: {
      observation: `${dayStemGod}.${state}`,
      theme: `${seasonDir}.${strength.band}`,
      action: branchGod,
      notice: noticeKey,
      variant,
    },
    reasoning: {
      dayMaster: STEMS[dm],
      dayStemGod: {
        key: dayStemGod,
        ...TEN_GOD_META[dayStemGod],
        element: dayStemElement,
        natalShare: share[dayStemElement],
        state,
      },
      season: { branch: today.month.branch, direction: seasonDir },
      strength,
      branchGod: { key: branchGod, ...TEN_GOD_META[branchGod], stem: STEMS[branchPrimary] },
      relation: { relation: best.relation, pillar: best.pillar },
      noticeElement,
      elementShare: share,
    },
  };
}

const count = (o: Record<string, unknown>) => Object.keys(o).length;

/** Authored string inventory. Every one of these is reachable; there are no dead keys. */
export const COPY_COUNTS = {
  observationKeys: count(OBSERVATION),
  observationStrings: count(OBSERVATION) * 3,
  themeStrings: count(THEME),
  actionStrings: count(ACTION),
  noticeStrings: count(NOTICE_RELATION) + count(NOTICE_ELEMENT),
  get totalStrings() {
    return this.observationStrings + this.themeStrings + this.actionStrings + this.noticeStrings;
  },
};
